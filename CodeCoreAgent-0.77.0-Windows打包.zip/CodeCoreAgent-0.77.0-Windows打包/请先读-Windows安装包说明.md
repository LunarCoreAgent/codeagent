# 请先读：Windows 安装包怎么打

这不是已经编好的 `.exe`。macOS 打不出 Windows 安装程序。
把本 zip 拷到 **Windows 10/11 x64**，解压后按下面做。

版本：**0.77.0**（鸿蒙原生版、系统深色与七种语言、新 CCA 图标）

## 解压后目录

| 路径 | 作用 |
|------|------|
| `请先读-Windows安装包说明.md` | 本文件 |
| `Windows封装配置说明-0.77.0.md` | 完整封装说明（配置文件、版本同步、验收） |
| `CHATGPT_WINDOWS_BUILD.md` | 交给 Windows 上 ChatGPT / Cursor 的构建任务 |
| `codeagent/` | 可构建的工程（源码 + packaging + scripts） |

## 在 Windows 上构建

1. 安装 [Python 3.12](https://www.python.org/downloads/)（勾选 Add to PATH）
2. 安装 [Inno Setup 6](https://jrsoftware.org/isinfo.php)，或：
   `choco install innosetup -y --no-progress`
3. 打开「命令提示符」或 PowerShell：

```bat
cd codeagent
python -m venv .venv
.venv\Scripts\activate
pip install -U pip
pip install -e ".[anthropic,openai,mcp,voice,desktop,packaging]"
python scripts\build_desktop.py
```

成功后在 `codeagent\dist\` 里会有：

- `codeagent-desktop-windows-amd64-setup.exe` — 安装向导
- `codeagent-desktop-windows-amd64.zip` — 便携包

也可以把 `CHATGPT_WINDOWS_BUILD.md` 整份交给 Windows 上的 AI 助手，让它按文档构建。

## 不要打进安装包的东西

`.venv`、API Key、`%USERPROFILE%\.codeagent` 用户数据。
