"""Privacy policy text for CodeCoreAgent (desktop).

``PRIVACY_VERSION`` bumps when material terms change; the UI re-prompts
until the user accepts the new version (stored in ``desktop.json``).
"""

from __future__ import annotations

from typing import Any

# Bump when clauses that affect user rights / data handling change.
PRIVACY_VERSION = "2026.09.04"

PRIVACY_TITLE = "CodeCoreAgent 隐私条款"

PRIVACY_SECTIONS: list[dict[str, str]] = [
    {
        "heading": "概述",
        "body": (
            "CodeCoreAgent（以下简称「本软件」）是由 LunarCoreAgent 开源维护的"
            "本机桌面 Agent。默认设计为本地优先：对话、项目、配置与密钥保存在"
            "您的设备上。本条款说明我们如何处理与隐私相关的数据。"
        ),
    },
    {
        "heading": "本机存储的数据",
        "body": (
            "本软件会在您的用户目录下写入本地文件（通常为 ~/.codeagent/），"
            "以及您指定的项目文件夹。可能包括：应用配置、模型端点与 API 密钥"
            "（密钥单独存放且权限受限）、对话与项目记录、技能与记忆、权限审计、"
            "日志与工作流状态等。这些数据不会由本软件自动上传到 LunarCoreAgent"
            "的服务器。"
        ),
    },
    {
        "heading": "发送到第三方的数据",
        "body": (
            "当您配置并选用云端或局域网大模型服务（例如 DeepSeek、通义、"
            "OpenAI 兼容网关、本机/局域网 Ollama 等）时，为完成推理，本软件会将"
            "您发起的对话内容、工具相关上下文、以及完成任务所需的代码或文件片段"
            "发送至您所指定的服务端点。该等传输受对应服务商的隐私政策与服务条款"
            "约束；本软件仅作为您配置的客户端转发请求。"
        ),
    },
    {
        "heading": "遥测与广告",
        "body": (
            "当前版本不包含内置遥测、广告 SDK，也不会向 LunarCoreAgent 回传"
            "使用统计。若未来引入可选诊断功能，将单独说明并默认关闭或另行征得同意。"
        ),
    },
    {
        "heading": "权限与工具执行",
        "body": (
            "Agent 可在您授权的范围内读写文件、执行命令或调用外部工具。"
            "请通过「权限控制」与执行前确认合理限制高风险操作。因工具执行产生的"
            "本机改动与副作用由您自行管理。"
        ),
    },
    {
        "heading": "开源许可",
        "body": (
            "本软件以 MIT 许可证发布。源代码与发行包不含对您个人数据的额外权利主张；"
            "本隐私条款不改变 MIT 许可证对软件本身的授权范围。"
        ),
    },
    {
        "heading": "条款更新",
        "body": (
            "隐私条款更新后，应用会提示您再次阅读并确认。继续使用即表示您知悉"
            "最新条款。若不同意，请停止使用并卸载本软件，同时可自行删除本地"
            "~/.codeagent 目录中的数据。"
        ),
    },
    {
        "heading": "联系方式",
        "body": (
            "项目仓库：https://github.com/LunarCoreAgent/codeagent\n"
            "如有隐私相关问题，请通过仓库 Issues 联系维护者。"
        ),
    },
]


def privacy_document() -> dict[str, Any]:
    """Structured policy for the desktop UI / API."""
    return {
        "version": PRIVACY_VERSION,
        "title": PRIVACY_TITLE,
        "sections": list(PRIVACY_SECTIONS),
        "updated": PRIVACY_VERSION,
    }


def privacy_markdown() -> str:
    """Plain markdown mirror (also written to PRIVACY.md)."""
    lines = [
        f"# {PRIVACY_TITLE}",
        "",
        f"版本：{PRIVACY_VERSION}",
        "",
    ]
    for sec in PRIVACY_SECTIONS:
        lines.append(f"## {sec['heading']}")
        lines.append("")
        lines.append(sec["body"])
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"
